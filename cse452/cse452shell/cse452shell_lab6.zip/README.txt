Name: Linxuan (Michael) Yang
Email: yanglinxuan@wustl.edu

1. Did not create any extra class, but added extra methods.I added recurisve methods to calculate the intersections as well as the different components of the colors. 

2. No known bugs. The all_objects.sc has a red cylinder in there, but it is also the case in the demo. 

3. No memory leaks because "new" keyword is never used and shared pointers are used all the time. 

3. Did not implement any extra credit. 

4. Discussed this lab with Wei Weng, especially how to handle the pointers to the objects such that they are not lost when the current method pops.  

5. Thank you for your grading this semester! :)